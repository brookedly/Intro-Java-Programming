//Brooke Ly brookedl 33256705
//Sunaina Kumar sunainak 27947698

public class lab4
{
	public static void main(String[] args)
    {
        TrainSimulation ts = new TrainSimulation();
        ts.start();
    }
}